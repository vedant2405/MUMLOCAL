from django.db import models

# Create your models here.
class Trains(models.Model):
    tno=models.CharField(primary_key=True,max_length=50)
    tname=models.CharField(max_length=50)
    rid=models.ForeignKey('Route',on_delete=models.CASCADE)

    def __str__(self):
        return self.tno

class Route(models.Model):
    rid=models.CharField(max_length=50)
    ostation=models.CharField(max_length=50)
    dstation=models.CharField(max_length=50)
    def __str__(self):
        return self.rid

class Station(models.Model):
    sid=models.CharField(primary_key=True,max_length=50)
    sname=models.CharField(max_length=50)
    def __str__(self):
        return self.sid


class RouteStation(models.Model):
    tno=models.ForeignKey('Trains',on_delete=models.CASCADE)
    sid=models.ForeignKey('Station',on_delete=models.CASCADE)
    rid=models.ForeignKey('Route',on_delete=models.CASCADE)
    order=models.IntegerField()
    atime=models.CharField(max_length=50)

class Reservation(models.Model):
    tno=models.ForeignKey('Trains',on_delete=models.CASCADE)
    user=models.CharField(max_length=50)
    nos=models.IntegerField()
    date=models.CharField(max_length=50)
    amt=models.IntegerField()
    cls=models.CharField(max_length=50)
    status=models.CharField(max_length=50)
    pnr=models.CharField(max_length=50)
    src=models.CharField(max_length=50)
    des=models.CharField(max_length=50)

class User_Proj(models.Model):
user_id = models.ForeignKey(User,on_delete = models.CASCADE)
Age = models.IntegerField(null = False,default=18)
City = models.CharField(max_length = 30,default="Mumbai")
Pincode = models.IntegerField(default=000000)
Region = models.CharField(max_length=10,default='Goregaon')


class Passenger(models.Model):
passenger_id = models.CharField(primary_key = True,max_length =5)
user_id = models.ForeignKey(User,on_delete = models.CASCADE)

class Ticket(models.Model):
Ticket_no = models.CharField(max_length = 10,primary_key= True)
Total_passenger = models.IntegerField(validators = [MaxLengthValidator(3)])
Passenger_id = models.ForeignKey(Passenger,on_delete = models.CASCADE)
Validity = models.DateTimeField(null = True)
Ticket_status = models.CharField(max_length = 20)
#class Books(models.Model):












